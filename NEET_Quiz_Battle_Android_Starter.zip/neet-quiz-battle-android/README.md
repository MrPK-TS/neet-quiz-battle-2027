# NEET Quiz Battle — Android starter

This folder packages the HTML quiz prototype into a native Android project using Capacitor.
It is a starter project, not a built APK/AAB and not yet Play Store-ready.

## What you need
- A computer (Windows, macOS, or Linux)
- Node.js LTS and npm
- Android Studio, including the Android SDK
- A Google Play Console developer account when you are ready to publish

## Build the Android project
1. Extract this ZIP on your computer.
2. Install Node.js LTS and Android Studio.
3. Open a terminal in this folder.
4. Run:

   npm install
   npx cap add android
   npx cap sync android
   npx cap open android

5. Android Studio opens the generated `android` project. Let Gradle sync and install any SDK components it requests.
6. Connect your Android phone with USB debugging enabled, or use an emulator, then press Run to test.
7. Fix and test any issues before preparing a release.

## Create a Play Store bundle (AAB)
1. In Android Studio, choose **Build > Generate Signed Bundle / APK**.
2. Choose **Android App Bundle**.
3. Create and securely back up a new signing key, or select your existing upload key.
4. Build the release bundle. Android Studio will show the output path.
5. In Play Console, create the app and upload the `.aab` to an internal testing release first.
6. Complete the store listing, app content, privacy policy, Data safety, content rating, target audience, and other required declarations.
7. Test the app thoroughly. New personal developer accounts created after 13 Nov 2023 currently need a closed test with at least 12 testers opted in continuously for 14 days before applying for production access. Check current Play Console requirements.
8. After requirements and review are complete, roll out to Production.

## Important before publishing
- The package ID `com.pranit.neetquizbattle` is a placeholder-style ID. Change it to a unique ID you control before your first Play Console upload. Once published, changing it means a different app.
- Replace the sample developer name/contact details in Play Console with accurate details.
- Prepare a privacy policy and complete Data safety accurately. This prototype does not currently need accounts or collect quiz results on a server, but review the actual final app and any SDKs before declaring data practices.
- Create a 512×512 app icon, feature graphic, phone screenshots, store description, and support contact.
- Do not include copyrighted NEET papers or copied coaching content unless you have permission. Use original questions or content you are licensed to use.
- Keep your signing key private and backed up. Never share it in chat.
- Play Console developer registration is for adults (18+). If you are under 18, ask a parent/guardian to handle account registration and publishing with their own accurate information; do not misrepresent your age or identity.
